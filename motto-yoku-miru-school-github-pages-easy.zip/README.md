# もっとよくみる｜学校に行く

「大変よく頑張りました展」の3D体験（学校版・発見ルート7つ）です。

## GitHub Pages に公開する

このZIPは **GitHub Pages用のWebサイト一式** で、`index.html` は3D体験を1つのHTMLにまとめたものです。

### 方法A：リポジトリにZIPをアップロードしてGitHub Actionsで公開する

1. `motto-yoku-miru-school` という公開GitHubリポジトリを作成します。
2. 「Publish school exhibition」GitHub Actionsワークフローが設定済みなら、このZIPを**解凍せず、ファイル名そのまま**アップロードします。
3. Settings → Pages → Build and deployment → Source を **GitHub Actions** にします。
4. GitHub Actionsの成功を確認すると、`https://hinakooooooooo.github.io/motto-yoku-miru-school/` で公開されます。

### 方法B：ZIPを解凍して直接アップロードする

1. ZIPを解凍します。
2. **中身のファイル** `index.html`、`THREE-LICENSE.txt`、`.nojekyll` などをリポジトリの最上位に置きます（ZIP自体は置きません）。
3. Settings → Pages → Deploy from a branch → `main` → `/ (root)` を指定します。

**注意：方法Aと方法Bは異なる公開方法なので、PagesのSource設定を混同しないでください。**

## 7つの発見

- 移動教室：走って間に合った
- 朝練：8時からの朝練に遅刻せずに来た
- 授業：眠い中でも受けた
- 友達との喧嘩：行きたくない気持ちがあっても登校した
- 挙手：誰も手を挙げないときに手を挙げた
- 授業準備：当てられる前に答えを考えておいた
- お腹：鳴りそうなお腹をこらえた

こちらのZIPはGitHub Pages向けの単体動作HTMLで、プログラム自体の編集には元の `gakkou-ni-iku-source-final` を使ってください。Three.jsのライセンスは `THREE-LICENSE.txt` を参照してください。
